# Gather 1.8.3 direction

Keep case data local and source public. Make deletion clear: optional-backup case deletion and scoped lookup-history clearing. Preserve fast project-free lookup. Privacy copy must distinguish browser-local case storage from deliberate external searches and separate exports.

## Narrow backlog

1. **Native acceptance of the completed 1.8.3 workspace.** Run the Chrome/Edge checklist on an allowed installation: toolbar, side-panel invocation, activeTab, browser zoom, downloads and realistic controlled full-page pages. Fix concrete failures before expanding scope. The four-view redesign and rendered workflows are implemented; the original design brief remains as historical rationale.
2. **Next bounded feature: local Quick Parts / Reference Library.** Start with Client Communication and Document Language collections, fast deterministic search, clear source/approval labels, scoped suggestions and temporary reviewed composition. Follow [the implementation proposal](QUICK-PARTS-DIRECTION.md). The generic engine belongs in public source; actual organization content is a separately imported local pack. Inspect authorized real exports before fixing taxonomy or calling language approved. No AI, email sending or live OneNote dependency.
3. Strengthen adapters from current primary evidence and controlled fixtures; ambiguous failures remain technical/unknown. Validate top-level full-page capture on representative controlled pages before adding scrolling-element capture. Evaluate user-selected custom roots separately with explicit permission and revoked/disconnected-folder recovery.
4. Defer full Gather Bar, broader workflow packs/QC engines, richer annotations, encrypted resume capsules and optional AI assistance. The narrow local reference-pack importer above does not imply those systems ship.

No passive browsing collection, cloud case storage, name-based people merging, automated relationship/identity conclusions or threat scoring. X remains search-only. Native mobile integration requires its actual source and separate scope.

## Quick Parts product boundary

Quick Parts is not included in 1.8.3. Its design remains in the separate implementation proposal. Search should remove the need to remember OneNote page titles. Analysts select language and review the final draft. Recorded coverage/account states can explain why a part may be useful, never establish a conclusion or prescribe a response. Actual SST source material is not present, so categories and approval mappings remain provisional; this does not block generic engine/UX work using fictional fixtures. Existing Gather has no ongoing-scan schedule model; do not infer that state.
