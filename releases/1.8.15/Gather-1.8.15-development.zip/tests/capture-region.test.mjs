import test from 'node:test';import assert from 'node:assert/strict';
import {regionPlan,acquireRegionCapture} from '../account-id-tool/capture-region.js';
import {CAPTURE_LIMITS,CaptureStopped} from '../account-id-tool/capture-engine.js';
const metrics={url:'https://example.test',width:1000,height:800,scrollX:0,scrollY:55,totalHeight:2600,devicePixelRatio:2,visualScale:1};
const rect={x:40,y:200,width:260,height:1700};
test('scrolling region covers the selected extent and only the needed viewports',()=>{const p=regionPlan(metrics,rect);assert.deepEqual(p.positions,[200,1000,1800]);assert.equal(p.originY,200);assert.equal(p.height,3400);assert.equal(p.bounded,false);});
test('bottom selection starts in the final viewport and retains crop offset',()=>{const p=regionPlan(metrics,{x:20,y:2400,width:100,height:200});assert.deepEqual(p.positions,[1800]);assert.equal(p.originY,1800);assert.equal(p.height,1600);});
test('scrolling region bounds huge/infinite selections by tile and pixel limits',()=>{for(const limits of [{...CAPTURE_LIMITS,maxTiles:2},{...CAPTURE_LIMITS,maxPixels:4000000}]){const p=regionPlan({...metrics,totalHeight:900000},{...rect,height:890000},2,limits);assert.equal(p.bounded,true);assert.ok(p.positions.length<=limits.maxTiles);assert.ok(p.width*p.height<=limits.maxPixels);}});
test('selection above the initial viewport and horizontal page offset remain document coordinates',()=>{const p=regionPlan({...metrics,scrollY:1000,scrollX:80},{x:90,y:100,width:100,height:1600});assert.equal(p.originX,80);assert.deepEqual(p.positions,[100,900]);});
test('invalid region and nonfinite geometry fail before capture',()=>{for(const invalid of [{...rect,x:-1},{...rect,y:-1},{...rect,width:NaN},{...rect,width:0},{...rect,y:2600},{...rect,x:990,width:100}])assert.throws(()=>regionPlan(metrics,invalid));});
function adapter({abort,changed=false,failAt=Infinity,shiftAt=Infinity}={}){
 let y=metrics.scrollY,now=1000,shots=0;const shotTimes=[];let restored=false,disposed=false,crop;
 const measure=()=>({...metrics,scrollY:y,totalHeight:changed?2700:metrics.totalHeight});
 return {shotTimes,get restored(){return restored;},get disposed(){return disposed;},get cropBounds(){return crop;},now:()=>now,async sleep(ms){now+=ms;if(abort)abort.abort();},async assertSource(){},async page(op,token,args){if(op==='scroll')y=args.y;if(op==='restore'){restored=true;y=55;}return measure();},async screenshot(){shots++;if(shots===failAt)throw new Error('Browser screenshot failed');shotTimes.push(now);if(shots===shiftAt)y+=10;return new Blob(['tile '+shots]);},async dimensions(){return {width:2000,height:1600};},async compose(tiles,plan){assert.equal(plan.originY,200);return new Blob(['composed '+tiles.length]);},async crop(blob,rect){crop=rect;return {blob:new Blob(['selected']),bounds:rect};},dispose(){disposed=true;}};
}
const selection={documentRect:rect,viewport:metrics,pageHeight:2600};
test('extended selection preserves original tiles, paces screenshots, crops selected pixels and restores page',async()=>{const a=adapter(),r=await acquireRegionCapture({selection,adapter:a});assert.equal(r.status,'complete');assert.equal(r.assets.filter(x=>x.role==='tile').length,3);assert.equal(r.assets[0].kind,'selection');assert.deepEqual(r.dimensions,{width:520,height:3400});assert.ok(a.shotTimes.slice(1).every((t,i)=>t-a.shotTimes[i]>=650));assert.equal(a.restored,true);assert.equal(a.disposed,true);});
test('cancellation restores source without a successful screenshot record',async()=>{const abort=new AbortController(),a=adapter({abort});await assert.rejects(acquireRegionCapture({selection,adapter:a,signal:abort.signal}),CaptureStopped);assert.ok(a.restored&&a.disposed);});
test('source movement discards unvalidated tiles and restores page',async()=>{const a=adapter({shiftAt:2});await assert.rejects(acquireRegionCapture({selection,adapter:a}),CaptureStopped);assert.ok(a.restored&&a.disposed);});
test('failed later screenshot retains only validated selected pixels and labels partial',async()=>{const a=adapter({failAt:2}),r=await acquireRegionCapture({selection,adapter:a});assert.equal(r.status,'partial');assert.equal(r.assets.filter(x=>x.role==='tile').length,1);assert.deepEqual(r.dimensions,{width:520,height:1600});assert.ok(r.limitations.some(x=>x.includes('screenshot failed')));assert.ok(a.restored&&a.disposed);});
test('changed page height and tile truncation never claim complete',async()=>{for(const a of [adapter({changed:true}),adapter()]){const r=await acquireRegionCapture({selection,adapter:a,limits:{maxTiles:1}});assert.equal(r.status,'partial');assert.equal(r.assets.filter(x=>x.role==='tile').length,1);assert.ok(a.restored);}});
test('fractional crop bounds include outward-rounded high-DPI edge pixels',async()=>{const a=adapter(),r=await acquireRegionCapture({adapter:a,selection:{...selection,documentRect:{...rect,x:40.25,width:260.5}}});assert.equal(r.dimensions.width,522);assert.equal(a.cropBounds.x,80);});
test('live selection refuses horizontal clipping instead of silently shrinking width',async()=>{
 assert.throws(()=>regionPlan(metrics,{...rect,x:900,width:100.5}),/unavailable/);
 const a=adapter();a.crop=async()=>({blob:new Blob(['wrong']),bounds:{width:500,height:3400}});
 await assert.rejects(acquireRegionCapture({adapter:a,selection}),/omit selected pixels/);assert.ok(a.restored);
});
test('aspect mismatch of several pixels fails even when the old relative tolerance accepted it',async()=>{
 const a=adapter();a.dimensions=async()=>({width:2000,height:1590});
 await assert.rejects(acquireRegionCapture({adapter:a,selection}),CaptureStopped);assert.ok(a.restored);
});
