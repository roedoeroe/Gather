import {extractLookup, normalizeLookup, pageAccessIssue} from './core.js';
import {readProfileInPage} from './profile-read-client.js';

export const isExtension = Boolean(globalThis.chrome?.runtime?.id && globalThis.chrome?.scripting);
const ownedTabs = new Set();
const abortError = () => new DOMException('Lookup stopped', 'AbortError');
function check(signal) { if (signal?.aborted) throw abortError(); }
const SETTLE_MS = 2000, SETTLE_INTERVAL_MS = 250;
function matchesProfile(url, profile) { try { return normalizeLookup(url).key === profile.key; } catch { return false; } }
async function sameCurrentProfile(tabId, profile) {
  const tab = await chrome.tabs.get(tabId);
  return matchesProfile(tab.url, profile) && (!tab.pendingUrl || matchesProfile(tab.pendingUrl, profile));
}
function pause(ms, signal) {
  return new Promise((resolve, reject) => {
    check(signal);
    const onAbort = () => { clearTimeout(timer); reject(abortError()); };
    const timer = setTimeout(() => { signal?.removeEventListener('abort', onAbort); resolve(); }, ms);
    signal?.addEventListener('abort', onAbort, {once: true});
  });
}
export async function closeOwnedTabs() {
  await Promise.all([...ownedTabs].map(async id => { try { await chrome.tabs.remove(id); } catch {} ownedTabs.delete(id); }));
}

async function fetchSource(profile, signal) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal?.addEventListener('abort', abort, {once: true});
  const timer = setTimeout(abort, 12000);
  try {
    check(signal);
    // Only normalized, allowlisted profile URLs ever reach this function.
    const response = await fetch(profile.content?normalizeLookup(profile.originalUrl||profile.sourcePageUrl||profile.url).url:profile.url, {credentials: 'omit', signal: controller.signal, redirect: 'follow', cache: 'no-store'});
    if (!response.ok) return {error: `The site returned HTTP ${response.status}. Open the profile to check its response, then retry.`};
    if (!response.body) return {error: 'The site returned no page source'};
    const reader = response.body.getReader(), decoder = new TextDecoder(); let html = '';
    try {
      for (;;) {
        const {done, value} = await reader.read();
        if (done) break;
        html += decoder.decode(value, {stream: true});
        if (html.length > 15000000) { await reader.cancel(); return {error: 'Page source is too large'}; }
      }
      html += decoder.decode();
    } finally { reader.releaseLock(); }
    return extractLookup(html, profile, response.url);
  } catch (error) {
    check(signal);
    return {error: error.name === 'AbortError' ? 'The site took too long to respond' : 'The site could not be reached'};
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
}

async function readBrowserPage(profile, signal, onStage, tabOwner, includeName) {
  check(signal);
  const tab = await chrome.tabs.create({url: profile.content?normalizeLookup(profile.originalUrl||profile.sourcePageUrl||profile.url).url:profile.url, active: false});
  ownedTabs.add(tab.id);
  try {
    if (tabOwner) await tabOwner.track(tab.id);
    else await chrome.runtime.sendMessage({type: 'trackTab', tabId: tab.id});
    check(signal);
    onStage?.('Reading browser page…');
    const deadline = Date.now() + 22000;
    let last = {error: 'Page did not finish loading. Open it, sign in if needed, and retry.'};
    while (Date.now() < deadline) {
      await pause(1000, signal);
      const state = await chrome.tabs.get(tab.id);
      if (state.status !== 'complete') continue;
      let actual;
      try { actual = normalizeLookup(state.url); } catch { return {error: pageAccessIssue('',state.url)||'The browser page did not return a supported profile URL. Open the intended profile and retry.'}; }
      if (actual.platform !== profile.platform) return {error: 'The profile redirected outside its platform'};
      const snapshot = await readProfileInPage(tab.id, profile, {includeName});
      check(signal);
      last = snapshot.result;
      if (last.id || last.accountState==='GONE' || /security check|sign in|Multiple account IDs|different profile/.test(last.error || '')) return last;
      // Allow hydrated profile data to arrive, but never solve login or CAPTCHA screens.
      if (Date.now() > deadline - 17000) return last;
    }
    return last;
  } finally {
    try { await chrome.tabs.remove(tab.id); } catch {}
    try {
      if (tabOwner) await tabOwner.untrack(tab.id);
      else await chrome.runtime.sendMessage({type: 'untrackTab', tabId: tab.id});
    } catch {}
    ownedTabs.delete(tab.id);
  }
}

export async function resolveProfile(profile, {signal, browserFallback = true, onStage, includeName = false, tabOwner, currentTabId} = {}) {
  check(signal);
  if (profile.directId && !includeName) return {id: profile.directId, method: 'ID in link'};
  const fallbackId = result => profile.directId && !result.id && result.accountState!=='GONE' ? {id: profile.directId, method: 'ID in link', displayName: '', nameWarning: result.error} : result;
  if (!isExtension) return fallbackId({error: 'Install the extension to use live lookup. Page-source import works here.'});
  if (Number.isInteger(currentTabId)) {
    onStage?.('Reading current page…');
    try {
      let tab=await chrome.tabs.get(currentTabId);
      const deadline=Date.now()+SETTLE_MS;
      // A just-opened tab may still expose its previous/blank committed URL.
      // Wait only when its explicit pending URL is the requested profile.
      while(profile.platform==='instagram'&&!matchesProfile(tab.url,profile)&&matchesProfile(tab.pendingUrl,profile)&&Date.now()<deadline){
        await pause(Math.min(SETTLE_INTERVAL_MS,deadline-Date.now()),signal);
        tab=await chrome.tabs.get(currentTabId);
      }
      let actual;
      try {actual=normalizeLookup(tab.url);} catch {return {error:'The current page changed. Open the profile and run it again.'};}
      if(actual.key!==profile.key||tab.pendingUrl&&!matchesProfile(tab.pendingUrl,profile))return {error:'The current page changed. Open the profile and run it again.'};
      let snapshot=await readProfileInPage(currentTabId,profile,{includeName});
      check(signal);
      while(profile.platform==='instagram'&&snapshot.result.error?.startsWith('No matching account ID')&&Date.now()<deadline){
        onStage?.('Waiting briefly for profile data…');
        await pause(Math.min(SETTLE_INTERVAL_MS,deadline-Date.now()),signal);
        if(!await sameCurrentProfile(currentTabId,profile))return {error:'The page changed during lookup. Open the intended profile and retry.'};
        snapshot=await readProfileInPage(currentTabId,profile,{includeName,documentId:snapshot.documentId,reuseReader:true});
        check(signal);
      }
      if(snapshot){
        const result=snapshot.result;
        if(!await sameCurrentProfile(currentTabId,profile))return {error:'The page changed during lookup. Open the intended profile and retry.'};
        if(result.id||result.accountState==='GONE')return {...result,method:'Current page · '+result.method};
        // Authentication, conflicting IDs and a different profile are explicit
        // failures. Only missing hydrated data triggers an automatic source read.
        if(!result.error?.startsWith('No matching account ID')&&!(profile.content&&result.error?.startsWith('Could not determine the owner')))return result;
        onStage?.('Reading profile source automatically…');
        const source=await readProfileInPage(currentTabId,profile,{source:true,includeName,documentId:snapshot.documentId});
        check(signal);
        const latest=await chrome.tabs.get(currentTabId);
        if(!matchesProfile(latest.url,profile)||latest.pendingUrl&&!matchesProfile(latest.pendingUrl,profile))return {error:'The page changed during lookup. Open the intended profile and retry.'};
        const found=source.result;
        if(found.id||found.accountState==='GONE')return {...found,method:'Current profile source · '+found.method};
        if(profile.platform!=='instagram'||!found.error?.startsWith('No matching account ID'))return found;
        // A signed-in page can omit the profile data exposed by the public
        // response. Previously only a second, pasted-link lookup tried this
        // path. Do it once in the original operation, without cookies or a tab.
        onStage?.('Checking public profile source…');
        const publicResult=await fetchSource(profile,signal);
        check(signal);
        // Pin the original document and recheck hydration after the request.
        // Navigation, access checks and conflicting IDs must never be hidden
        // by a result from the public response.
        const current=await readProfileInPage(currentTabId,profile,{includeName,documentId:source.documentId});
        check(signal);
        const stillCurrent=await chrome.tabs.get(currentTabId);
        if(!matchesProfile(stillCurrent.url,profile)||stillCurrent.pendingUrl&&!matchesProfile(stillCurrent.pendingUrl,profile))return {error:'The page changed during lookup. Open the intended profile and retry.'};
        if(/Multiple account IDs|different account ID/.test(publicResult.error||''))return publicResult;
        if(current.result.id){
          if(publicResult.id&&current.result.id!==publicResult.id)return {error:'The page and public profile returned different account IDs. Gather did not choose either ID.'};
          return {...current.result,method:'Current page · '+current.result.method};
        }
        if(!current.result.error?.startsWith('No matching account ID'))return current.result;
        if(publicResult.id){
          if(!includeName)delete publicResult.displayName;
          return {...publicResult,method:'Public profile source · '+publicResult.method};
        }
        return {error:'No matching account ID was available from this page or its public profile.'+(!publicResult.error?.startsWith('No matching account ID')&&publicResult.error?' '+publicResult.error:'')};
      }
      return {error:'The current page returned no readable source. Reload the profile, then retry.'};
    }catch{check(signal);return {error:'Gather could not read this tab. Reopen Gather using its toolbar button on the profile, then retry.'};}
    // This explicit operation reads source in the same authorized tab/document.
    // The existing user tab is never tracked as temporary or closed by Gather.
  }
  onStage?.('Fetching profile…');
  const direct = await fetchSource(profile, signal);
  check(signal);
  if (direct.id || direct.accountState==='GONE' || !browserFallback) return fallbackId(direct);
  try { return fallbackId(await readBrowserPage(profile, signal, onStage, tabOwner, includeName)); }
  catch (error) { check(signal); return fallbackId({error: 'Could not read the browser page. Open the profile, then choose Find IDs on this page.'}); }
}
