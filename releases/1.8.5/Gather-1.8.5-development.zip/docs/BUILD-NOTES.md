# Gather 1.8.5 direct capture implementation

`page-tools.js` is a lightweight popup controller: three direct screenshot actions, scan filing, optional subject and secondary metadata/detachment actions. It reads the tab context once and preserves the displayed snapshot across default/assignment updates. Explicit dropdown selection assigns the exact tab; explicit default action detaches. Capture, metadata save and lookup origin use this snapshot. No screenshot/blob module is preloaded into the popup. The side-panel entry retains its native user-gesture handler.

Capture launch and metadata save validate the frozen project/scan/search and expected URL before work. The existing engine checks active source tab/document around screenshots, performs bounded acquisition, restores temporary page changes and preserves originals. No source acquisition or byte-storage redesign was necessary.

`capture-viewer.js/css` provides a read-only, keyboard-scrollable width/whole-image viewer for completion and inspection. Selection coordinates move behind a disclosure, preserving keyboard access. Record IDs in `workspace-links.js` open a specific scan/capture; initialization validates the link and emits readiness so an older active scan cannot consume it. Worker sender-page checks now strip both queries and fragments, preserving extension-ID/path authorization.

Explicit current-page lookup now returns its observed extraction result or access failure, instead of fetching another page. Retry validates the same profile and preserves the existing batch/origin. Ordinary captcha libraries/login links cannot alone trigger sign-in guidance. Known redirect screens, rendered sign-in/challenge text and structured errors provide specific advice; HTTP errors no longer all suggest sign-in. Gone/identity rules and exact string IDs remain unchanged.

Manifest/package/version_name agree on 1.8.4. No permissions, runtime dependencies, worker dynamic imports or storage-schema changes. Previous packages remain immutable. Evidence distinguishes rendered browser/API-double tests from native acceptance.

---

# Gather 1.8.3 workspace implementation

The active 1.8.2 runtime was verified against its packaged bytes before resuming. The incomplete earlier navigation sketch and 1.8.2 release remain preserved. This release changes real extension UI, not storage/worker/extraction behavior.

`workspace-navigation.js` manages four stable accessible panels with roving focus, Arrow/Home/End navigation, enum-only reload hashes and in-window scroll positions. Tab switches replace the current URL state rather than adding browser-history entries; they do not change filing context. Research secondary History selects searches/activity. `workspace-layout.css` is loaded by the workspace only. At narrow widths a Library disclosure replaces the expanded case list. `workspace-focus.js` restores corresponding controls after list updates without stealing focus from a dialog or a user who moved elsewhere.

Explicit hosts separate common subject selection, subject management, privacy settings and capture preferences. Side-panel mode skips deep management and shows at most three open tasks plus the next queued search. Empty management/tasks do not fill the panel. Its independent refresh no longer accesses the absent privacy heading.

`capture-ui.js` renders a bounded 12-image page, revokes obsolete Blob URLs and verifies selected image bytes. A modal inspector provides review/inclusion, edit/export/retry and source/hash details. Missing selected derivatives never fall back to an original. Export captures the current scan ID and lists included images before a scope confirmation; cross-scan subject browsing does not change export scope. Errors are visible in the inspector/global status. Subject editing freezes its project before asynchronous dialogs.

`case-ui.js` has one New case entry with optional intake, stale-preview invalidation and unchanged reviewed-seed validation. Blank cases use existing project creation. Red deletion/history actions remain in Settings with the selected case named. Existing privacy, signature/revision, backup and cancellation protections remain. The shared editor now assigns `type` only to input elements; textarea.type is read-only, which previously broke note/excerpt creation.

No worker graph dynamic imports, permissions, binary schema, runtime dependencies or organization content were added. Quick Parts remains the next bounded feature, not shipped UI. See current TESTING.md; prior implementation notes follow for architecture context.

---

# Gather 1.8.2 privacy implementation

The partial `batches.js` edit was checkpointed before wiring; its 110-test baseline and all shipped module syntax passed. The completed release adds scoped destructive UI and race protection. Prior 1.8.1 source/packages and documentation are preserved.

`batches.js` serializes short history mutations with a shared Web Lock. A generation marker invalidates old batches/drafts after an atomic clear. It scrubs nested imported settings archives with a depth bound and preserves other preferences/case search drafts. Closing-page flushes route through a trusted background handler. Without Web Locks, page lookup writes route to the worker, whose fallback promise queue serializes them with privacy operations. Clearing is also serialized with workspace restore/journal operations. Import deliberately rebases batches to the current generation, without importing/exporting the runtime marker.

The worker serializes privacy commands with quick commands, aborts affected active lookup jobs and awaits their completion before removal. Full-tool windows abort and discard visible content on generation change or case-batch tombstones. Batch saves reject missing projects. Search drafts use the worker workspace queue and reject deleted scans; session edits share the deletion lock. IndexedDB tombstones reject late subject/image/settings writes. Case deletion scrubs identifiable case-linked lookup copies in nested settings archives, preserving unrelated settings and unassigned drafts. Existing revision/signature, cross-project-reference and pending-capture/restore guards remain.

The case UI freezes the reviewed name/project and revision/image signature, requires the typed name and offers backup or no-backup deletion. A requested backup is checked against that snapshot and its download must complete before removal. Data & Privacy and recent-history controls use explicit labels, red buttons, modal cancellation and status/error messages. Clear history preserves saved workspace research and binary images; deletion without backup creates no additional file.

Network audit of runtime JavaScript found only deliberate platform `fetch(profile.url, credentials: include)`, screenshot data-URL decoding, user-launched service tabs/links, and local blob downloads. No `storage.sync`, analytics, `sendBeacon`, WebSocket, XMLHttpRequest or case-upload endpoint was found. No permission changes. The public source repository contains fictional tests only. Browser history, OS/cloud backup of the browser profile and user-shared exports are outside Gather's storage contract.

The supported preview fallback is not a hosted replacement for the extension. In a browser missing Web Locks, case-session editing fails visibly rather than racing deletion; supported Chrome/Edge provide Web Locks. No forensic deletion claim is made. See TESTING.md for executed evidence.

## Source and checkpoints

The uploaded 1.6.1 manifest was verified before edits. The original ZIP and an extracted baseline remain preserved outside the working tree. The existing Git repository had only its README; that file was retained. Implementation is in `gather/account-id-tool`. No Google Drive source or prior temporary prototype was used. The 10 new tab-context tests cover integrated code; the unsaved earlier prototype was not counted.

1.6.2 freezes continuity before capture. 1.6.3 freezes visible/selection capture after rendered browser validation and before full-page exposure. 1.7.0 adds bounded full page, image derivatives, report integration and further fixes. 1.8.0 completes a bounded R3 case workflow on that foundation. The 1.7.0 source and ZIPs remain unchanged. A pre-final 1.8.0 snapshot also remains available. Historical 1.6.1 and 1.7.0 notes are in `history/`; they do not describe current test results.

The supplied R3 blueprint and both identical continuation notes were read fully. They guide product decisions within the user's implementation request; they do not establish that earlier tests passed, authorize unrelated external actions, or make the whole blueprint this release's scope.

## R3 additions

`account-state.js` distinguishes AVAILABLE / PRIVATE_INACCESSIBLE / GONE / UNKNOWN_TECHNICAL. GONE requires affirmative adapter evidence, timestamp and reason. Only the matching YouTube profile's exact structured error alert “This channel does not exist.” currently supplies that evidence. Authentication, security challenges, missing markup and absent IDs do not. Batch restoration validates evidence; gone rows stop retrying as unfinished and cannot manufacture an ID from their URL. Usable rows sort first, unresolved technical rows remain separate and gone rows appear quietly last. Saved account entities retain prior IDs, aliases and lifecycle observations; older observations cannot overwrite a newer lifecycle. Explicit former-alias search is editable and inherits its original lookup destination.

`case-model.js` adds `workspace.research` (version 1) with seeds, queue, coverage and analyst associations; the existing workspace schema remains version 1. Case Start parses explicit labels locally, splits supported lists/age/grade hints, and requires a review step. Contacts and unknown fields default excluded. Repeated person names are separate subjects; ordinary identical seed values may deduplicate. The parser is deterministic, not a general identity extractor. Context-menu intake uses only the selected text supplied by Chrome.

Subjects remain project-scoped IndexedDB records. Stable role IDs such as SOC-01 are assigned without interpreting SOC. Existing local subjects receive roles lazily without replacing their record IDs or history. Account observations and subjects stay distinct; candidate/confirmed/rejected associations require an explicit action and reason. Coverage tracks work, including “Searched — no reliable match,” independently of account availability.

Ephemeral Case stores approved intake names and resolved query values in `chrome.storage.session`; durable seeds hold tokens, and durable subjects hold role IDs. `case-session.js` serializes session-map edits with Web Locks. Queued and manual searches resolve values only for launch, log tokens and retain seed references; ephemeral search drafts are session-only. Lost session values require reviewed re-entry rather than guessed reconstruction. Local Case deliberately retains approved values. Raw intake is cleared on confirmation/cancellation. This is contextual minimization, not anonymization: saved sources, URLs, notes, titles, browser history and image pixels may still contain names. Hide friendly labels is explicitly a limited display control.

Case creation commits subjects and a pending workspace-write journal together. Backup restore preallocates subject mappings before merging research references; imported role, queue, association, finding and capture relationships survive ID conflicts. Global cross-type duplicate IDs, foreign-scope subject references and ephemeral subject records containing friendly names are rejected. Imported session maps are never restored from a private backup.

Captures freeze role/project/scan and retain stable Evidence IDs; role-only folder paths avoid intake names. Metadata-only save stores source/time/role and an Evidence ID without an image. New captures default to unreviewed and not included; legacy inclusion remains compatible. Toolbar capture uses the displayed frozen scope; Case Start management remains in the full workspace.

`evidence.html/js/css` previews a selected scan's included, non-excluded images and an Evidence-ID/sheet crosswalk. A portable HTML export embeds only the selected verified asset for each capture; a selected derivative excludes original image bytes and original hashes. Review source metadata/pixels before sharing. Limits are 40 captures / 64 MiB selected image bytes. Native Print / Save PDF and printer pagination have not been accepted here.

`case-close.js` scopes private binary backups and logical removal to one project. The 1.8.2 UI makes backup optional; both deletion paths retain revision/signature checks, atomic binary purge/journal recovery, tombstones and cross-project/pending-job guards. Related lookup archive copies and scoped draft/session context are removed; unrelated data and external files remain.

## Architecture and failure behavior

`tab-context.js` serializes small `chrome.storage.session` assignments. Search tabs are created inactive/blank, assigned, then navigated. Only `openerTabId` creates related context. Closed/replaced tabs are handled explicitly; browser restart discards session assignments. Same-tab navigation keeps explicit research assignment without treating navigation as evidence. Unknown opener means the displayed default is used, not a guessed search relationship.

`capture-launch.js` validates the UI's frozen destination against the workspace and snapshots source, subject, optional account/source and search references. One session lock prevents overlapping controllers, including after a service-worker restart. It opens a separate extension window without focusing it before acquisition. The active source tab, URL and document are checked around screenshots. A switch/navigation invalidates the current image; previously validated tiles may remain a clearly partial capture.

`capture-engine.js` runs in that extension document. It uses isolated-world scripting and `captureVisibleTab`, paced at least 650 ms apart across jobs. Full-page manipulation has an explicit finally restore plus a 15-second page-side watchdog if the controller disappears. Source navigation runs pagehide restoration. The watchdog may be delayed by browser throttling. No background content collection or permanent content script is installed.

Original screenshot PNGs (or full-page tiles) are immutable assets. A stitched full-page image, crop or flattened redaction is a derivative. The user can create sequential rectangular crops/redactions and a sidecar caption. This is not a general annotation graphics suite. Share exports never silently fall back to an original when an expected crop/redacted derivative is missing.

`capture-store.js` keeps subjects, metadata, settings and Blob assets in IndexedDB. Completion and its assets commit in one transaction. Failed/aborted writes do not claim Saved. Abandoned capture records become interrupted; active controller IDs are protected. There is no automatic research deletion. Storage-estimate checks are advisory; native quota failures still surface. Backups and exports are the recovery path for missing images.

`capture-backup.js` uses a documented length-prefixed binary format: ASCII `GATHER-BINARY-1\n`, little-endian uint32 UTF-8 JSON metadata length, metadata, then exact asset bytes in metadata order. Metadata includes `workspaceBackup` and `bundle`; asset sizes delimit the bytes and SHA-256 verifies each asset. No compression, path extraction or executable code is accepted. Maximum container size is 560 MiB and metadata 32 MiB. The format is not encrypted or signed. A hash is not an authenticity certificate.

Restoration validates first, stages the full archive, then serializes the workspace merge in the existing worker queue. Image/subject rows and a pending-workspace journal commit atomically. The journal finishes the exact Chrome storage write after interruption and is removed only after success. If later external edits conflict with that journal, Gather blocks rather than overwrite them; retain the backup and restore in a separate installation. Imported conflicting record IDs and derivative/search/subject links are remapped. Explicit observation references survive later movement of those observations.

`capture-files.js` exports an image and JSON companion via the Downloads API, checks completion, and records the actual uniquified image basename. Separate image/record downloads are not an OS atomic directory transaction: a failed second download leaves an incomplete export and Retry creates safe copies. The image remains in Gather. The JSON points to the corresponding image basename and carries its hash, source, timestamps, destination and limitations.

## Permissions and current primary sources

Added only `downloads` to 1.6.1's permissions; 1.8.0 adds none over 1.7.0. Existing platform host permissions, `activeTab`, scripting, storage, contextMenus, sidePanel and clipboardWrite are retained. No all-sites access, history, tabs, webNavigation, offscreen or unlimitedStorage grant was introduced.

Inspected current official Chromium sources on 2026-10-06:

- [Tabs API definition](https://github.com/chromium/chromium/blob/main/chrome/common/extensions/api/tabs.json): `captureVisibleTab` requires activeTab or all_urls; captureVisibleTab limit is 2 calls/second; openerTabId is browser-provided and optional.
- [Active-tab grant implementation](https://github.com/chromium/chromium/blob/main/extensions/browser/permissions/active_tab_permission_granter.cc): explicit grant, per-tab permissions, same-origin navigation retention and cross-origin revocation.
- [Storage API definition](https://github.com/chromium/chromium/blob/main/extensions/common/api/storage.json): in-memory session state, trusted-context access and bounded quota.
- [Downloads API definition](https://github.com/chromium/chromium/blob/main/chrome/common/extensions/api/downloads.webidl): filenames relative to Downloads, subdirectories allowed, absolute paths/backreferences rejected, conflictAction and completion/interruption states.

Chrome concept/reference URLs remain the user-facing documentation: [activeTab](https://developer.chrome.com/docs/extensions/develop/concepts/activeTab), [tabs](https://developer.chrome.com/docs/extensions/reference/api/tabs), [service-worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle), [downloads](https://developer.chrome.com/docs/extensions/reference/api/downloads). The documentation website returned proxy 403 here, so do not claim a successful current-site browse. The official source mirror was accessible. Capture processing deliberately lives outside the terminable worker; durable transactions/session state handle worker interruptions.

## Custom root folder evaluation (separate, not shipped)

A custom directory would require File System Access `showDirectoryPicker` from a visible top-level extension page and a user gesture, a stored DirectoryHandle, and explicit `readwrite` permission. Each write must check permission; automatic work must report revoked/disconnected access and retain the capture rather than repeatedly prompting. A user-initiated Retry/Choose folder can request permission again. Directory handles must not be exported into backups or treated as portable authorizations. See [File System Access API](https://developer.chrome.com/docs/capabilities/web-apis/file-system-access).

This environment's managed Chromium policy denies File System read/write guards and unpacked extension loading. Custom-root permission and disconnect behavior therefore cannot be accepted natively here. Shipping Downloads-relative export first preserves a clear supported boundary; no arbitrary-path claim or simulated directory picker is exposed in the product.

## Remaining limitations

Native toolbar, panel, activeTab, captureVisibleTab, Downloads, browser restart and Edge integration need acceptance on a permitted runner. Rendered browser tests use controlled API doubles, as documented. Live adapter behavior, including the narrow new YouTube gone-state handling, remains unverified. Infinite feeds/lazy content can change height, resulting in partial status; nested scrolling capture is subsequent work. Encrypted resume capsules, full Gather Bar, organization/workflow packs, automatic privacy scrubbing, custom roots, cloud sync, inferred identity and threat scoring are not part of this build.


## 1.8.5 capture workflow

`capture-selection.js` serializes a self-contained isolated-world page overlay. Closed shadow styles isolate the crosshair/modal and coordinate form from host CSS. User drag-release or keyboard confirmation removes the overlay before acquiring pixels. Source tab/URL/document, scroll, viewport, DPR and visual scale are checked; native image dimensions determine crop scale. Source selection is bounded to three minutes; a bounded frame flush cannot hang indefinitely when a source becomes inactive. Explicit screenshot-based selection remains under Page options. The original viewport and cropped derivative commit together. No persistent content script or new permission is needed.

`capture-output.js` verifies the current selected asset before image clipboard, PNG/JPEG save-as and print preview. Clipboard write is invoked synchronously with promised verified PNG bytes; explicit copy can retry when automatic copy is denied. Save-as sets downloads.saveAs true and conflictAction uniquify with a safe relative basename. Output conversion does not mutate originals or update structured folder-export state. The local print preview slices the selected image into up to 40 pages/48 million pixels with optional source captions; native printer/PDF layout requires acceptance. PNG/JPEG convenience downloads do not automatically add a sidecar; structured folder export remains the matching-image/record/hash route.

`capture-history.js` filters/groups exact record scopes; browsing all cases never selects a global destination. `capture-ui.js` renders twelve saved-image cards initially, resolves labels in each project and exposes deeper filters on demand. Selected deletion uses a reviewed JSON record snapshot checked in the same transaction as captures/assets/settings removal. Active capture/export and staged restore block deletion. `closed-capture` tombstones are runtime guards excluded from backups; deliberate import clears the imported record's tombstone. `failCapture` now updates atomically, so late failures neither overwrite completed images nor recreate deleted records. Binary schema/backup versions remain compatible.

`capture-launch.js` includes frozen source data in its session lock. Selection/full-page operations use the launch ID as token. `windows.onRemoved` wakes the actual worker to cancel the selector, restore page changes, mark unfinished work cancelled and clear seed/lock; unrelated windows are ignored. Page-side watchdogs remain. Processing lives in the controller, outside worker lifetime, and worker dependencies are static imports.

Current primary pages successfully read on 2026-10-07: [FireShot product](https://getfireshot.com/), [FireShot features](https://getfireshot.com/features.php), [Chrome scripting](https://developer.chrome.com/docs/extensions/reference/api/scripting), [Chrome tabs](https://developer.chrome.com/docs/extensions/reference/api/tabs), [Chrome downloads](https://developer.chrome.com/docs/extensions/reference/api/downloads), and [MDN extension clipboard](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Interact_with_the_clipboard). Scripting awaits returned promises; activeTab remains invocation-scoped; captureVisibleTab has a two-call/second limit, while Gather spaces acquisitions by at least 650 ms. Downloads filenames remain relative; no arbitrary custom-root write is implied. Clipboard image writes require applicable permission/focus; denial is recoverable. Prior documented website proxy failures refer to the earlier run; these specific current requests returned 200.
